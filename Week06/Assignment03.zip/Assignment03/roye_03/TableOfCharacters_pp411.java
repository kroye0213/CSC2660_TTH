package Assignment03.roye_03;


public class TableOfCharacters_pp411 {
    public static void main(String[] args) {
        for(int i = 32; i <= 126; i++)  
{  
System.out.println("The ASCII value of " + (char)i + "  =  " + i);  
    }
}
}
    
    
        
    

