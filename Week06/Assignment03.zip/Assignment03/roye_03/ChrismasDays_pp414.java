package Assignment03.roye_03;

public class ChrismasDays_pp414 
{

	public static void main(String [] args)
	{
		
	
		
		
		for(int i=1; i<=12;i++)
	{
		System.out.print("On the ");
	
		switch(i)
		{
		case 1:
			System.out.print("First");
			break;
			
			
		case 2:
			System.out.print("Second");
			break;
				
		case 3:
			System.out.print("Third");
			break;
			
		case 4:
			 System.out.print("Fourth");
			break;
			
		case 5:
			System.out.print("Fifth");
			break;
			
		case 6:
			System.out.print("Sixth");
			break;
		case 7:
			System.out.print("Seventh");
			break;
		case 8:
			System.out.print("Eighth");
			break;
		case 9:
			System.out.print("Ninth");
			break;
		case 10:
			System.out.print("Tenth");
			break;
		case 11:
			System.out.print("Eleventh");
			break;
		case 12:
			System.out.print("Twelfth");
			break;
			
		}
		
		
		System.out.println(" Day of Christmas my true love gave to me ");
		
		for(int m=1; m<=i; m++)
		{
			switch(m)
			{
			case 1:
				System.out.println(" A partridge in a pear tree ");
				break;
			case 2:
				System.out.println(" two Turtle Doves ");
				break;
			case 3:
				System.out.println(" three French Hens ");
				break;
			case 4:
				System.out.println(" four Calling Birds ");
				break;
			case 5:
				System.out.println(" five Golden Rings ");
				break;
			case 6:
				System.out.println(" six Geese a laying ");
				break;
			case 7:
				System.out.println(" seven Swans a swimming ");
				break;
			case 8:
				System.out.println(" eight Maids a milking ");
				break;
			case 9:
				System.out.println(" nine Ladies Dancing ");
				break;
			case 10:
				System.out.println(" ten Lords a leaping ");
				break;
			case 11:
				System.out.println(" eleven Pipers piping ");
				break;
			case 12:
				System.out.println(" twelve Drummers Drumming ");
				break;
			}
		}
		
		
	}
	}
}