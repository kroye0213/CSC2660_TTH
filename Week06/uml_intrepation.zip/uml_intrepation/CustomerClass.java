package uml_intrepation;

public class CustomerClass {
    private int CustomerID;
    private String CustomerName;
    private String Address;
    private int phone;
    public CustomerClass(){

    }
    public void AddCustomer() {
        
    }
    public void EditCustomer(){

    }
    public void DeleteCustomer(){
        
    }
}
