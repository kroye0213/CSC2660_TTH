public class ClubMemberAddressDemo {
    public static void main(String[] args) {
        Address addr1 = new Address();

        addr1.
    }
}
