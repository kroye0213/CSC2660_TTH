package uml_intrepation;

public class Product {
    private int ProductID;
    private float ProductPrice;
    private String ProductType;
    public Product(){

    }
    public void AddProduct() {

    }
    public void ModifyProduct(){

    }
    public void SelectProduct(int ProductID){
        
    }
}