package uml_intrepation;

import javax.sound.sampled.DataLine;

public class Order {
    private int OrderId;
    private int CustomerID;
    private String CustomerName;
    private int ProductID;
    private float Ammount;
    private DataLine OrderDate;
    public void CreateOrder() {
    
    }
    
    private void EditOrders(int OrderId) {
    }

    public Order() {

    }
}
