package uml_intrepation;

public class Stock {
    private int ProductID;
    private int Quality;
    private int ShopNo;
    public Stock(){

    }
    public void AddStock(){

    }
    public void ModifyStock(int ProductID){

    }
    public void SelectStockItem(int ProductID) {
        
    }
}
